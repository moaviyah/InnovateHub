export const PRIMARY = '#4C6FBF'
export const SECONDARY = '#FFFFFF'
