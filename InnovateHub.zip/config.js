// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAe_CvThMr3eCmlRoLG-Qg4b-I1zBGbZgg",
  authDomain: "innovatehub-e17cd.firebaseapp.com",
  projectId: "innovatehub-e17cd",
  storageBucket: "innovatehub-e17cd.appspot.com",
  messagingSenderId: "1003277630293",
  appId: "1:1003277630293:web:f6ef4d4c4ee9be60928ddc"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);