import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Chats = ({navigation}) => {
  return (
    <View>
      <Text>Chats</Text>
    </View>
  )
}

export default Chats

const styles = StyleSheet.create({})